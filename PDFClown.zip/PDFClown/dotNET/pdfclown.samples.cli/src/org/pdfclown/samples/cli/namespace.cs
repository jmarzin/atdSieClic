/**
  <summary>Samples demonstrating some of the available functionalities of PDF Clown.</summary>
*/
namespace org.pdfclown.samples.cli
{}
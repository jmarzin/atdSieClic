/**
  <summary>Features that enable a document to include higher-level information
  that is useful for the interchange of documents among applications [PDF:1.6:10].</summary>
*/
namespace org.pdfclown.documents.interchange{}
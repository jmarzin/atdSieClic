/**
  <summary>%Color space types used to specify the colors of graphics objects inside
  content streams [PDF:1.6:4.5].</summary>
*/
namespace org.pdfclown.documents.contents.colorSpaces{}
/**
  <summary>Features that support global information about the document
  [PDF:1.6:10.2].</summary>
*/
namespace org.pdfclown.documents.interchange.metadata{}
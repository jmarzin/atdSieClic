/**
  <summary>Features that allow a user to embed and play multimedia content within a PDF document [PDF:1.6:9].</summary>
*/
namespace org.pdfclown.documents.multimedia{}
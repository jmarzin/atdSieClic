/**
  <summary>Interactive forms (aka AcroForm) used to gather information interactively
from the user [PDF:1.6:8.6].</summary>
*/
namespace org.pdfclown.documents.interaction.forms{}
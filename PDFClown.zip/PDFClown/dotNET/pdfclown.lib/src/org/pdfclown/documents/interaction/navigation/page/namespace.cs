/**
  <summary>Features that enable the user to navigate from page to page within a document
  [PDF:1.6:8.3].</summary>
*/
namespace org.pdfclown.documents.interaction.navigation.page{}
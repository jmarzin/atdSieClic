/**
  <summary>External content objects that are able to be referenced from content stream
  objects [PDF:1.6:4.7].</summary>
*/
namespace org.pdfclown.documents.contents.xObjects{}
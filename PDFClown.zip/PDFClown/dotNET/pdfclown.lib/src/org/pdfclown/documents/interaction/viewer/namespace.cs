/**
  <summary>PDF viewer settings [PDF:1.6:8.1].</summary>
*/
namespace org.pdfclown.documents.interaction.viewer{}
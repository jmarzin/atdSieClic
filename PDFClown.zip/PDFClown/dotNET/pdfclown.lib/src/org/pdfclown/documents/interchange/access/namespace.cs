/**
  <summary>Features that support document accessibility [PDF:1.6:10.8].</summary>
*/
namespace org.pdfclown.documents.interchange.access{}
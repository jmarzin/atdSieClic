/**
  <summary>Content stream instructions [PDF:1.6:3.7.1].</summary>
*/
namespace org.pdfclown.documents.contents.objects{}
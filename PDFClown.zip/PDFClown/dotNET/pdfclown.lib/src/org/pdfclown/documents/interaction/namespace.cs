/**
  <summary>Features that allow a user to interact with a document
  on the screen [PDF:1.6:8].</summary>
*/
namespace org.pdfclown.documents.interaction{}
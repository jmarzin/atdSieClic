/**
  <summary>Types used to define the graphical appearance of PDF contents [PDF:1.6:3.7].</summary>
*/
namespace org.pdfclown.documents.contents{}
/**
  <summary>Custom form field appearance.</summary>
  <remarks>This package provides ready-to-use formatters to automate the composition of the graphic style of form fields.</remarks>
*/
namespace org.pdfclown.documents.interaction.forms.styles{}
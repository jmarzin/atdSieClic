using org.pdfclown;

/**
  <summary>File specifications used to reference the contents of other (either external or embedded)
  files [PDF:1.6:3.10].</summary>
*/
namespace org.pdfclown.documents.files
{}
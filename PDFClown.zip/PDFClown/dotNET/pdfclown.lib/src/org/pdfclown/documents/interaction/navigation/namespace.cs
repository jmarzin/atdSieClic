/**
  <summary>Features that allow a PDF viewer application to present the user with interactive overviews
  and page-specific views of a document [PDF:1.6:8.2-.3].</summary>
*/
namespace org.pdfclown.documents.interaction.navigation{}
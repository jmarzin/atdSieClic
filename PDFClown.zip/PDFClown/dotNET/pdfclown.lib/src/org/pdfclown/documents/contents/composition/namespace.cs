/**
  <summary>Typographic composition.</summary>
*/
namespace org.pdfclown.documents.contents.composition{}
/**
  <summary>Document-level objects [PDF:1.6:3.6].</summary>
*/
namespace org.pdfclown.documents{}
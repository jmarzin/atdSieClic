/**
  <summary>Actions used to perform specific operations when triggered [PDF:1.6:8.5].</summary>
*/
namespace org.pdfclown.documents.interaction.actions{}
/**
  <summary>Features that allow a PDF viewer application to present the user with an interactive,
  global overview of a document [PDF:1.6:8.2].</summary>
*/
namespace org.pdfclown.documents.interaction.navigation.document{}
/**
  <summary>Specialized graphic types.</summary>
*/
namespace org.pdfclown.documents.contents.entities{}
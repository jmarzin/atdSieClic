/**
  <summary>%Font type definitions used to draw text inside content streams
  [PDF:1.6:5].</summary>
*/
namespace org.pdfclown.documents.contents.fonts{}
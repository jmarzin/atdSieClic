/**
  <summary>%Stream encoding/decoding filters [PDF:1.6:3.3].</summary>
*/
namespace org.pdfclown.bytes.filters{}
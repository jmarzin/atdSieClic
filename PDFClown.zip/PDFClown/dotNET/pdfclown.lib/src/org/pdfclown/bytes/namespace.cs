/**
  <summary>I/O support.</summary>
*/
namespace org.pdfclown.bytes{}
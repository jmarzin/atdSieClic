/**
  <summary>Specialized tools for performing common operations on PDF files.</summary>
*/
namespace org.pdfclown.tools{}
/**
  <summary>File-level objects [PDF:1.6:3.4].</summary>
*/
namespace org.pdfclown.files{}
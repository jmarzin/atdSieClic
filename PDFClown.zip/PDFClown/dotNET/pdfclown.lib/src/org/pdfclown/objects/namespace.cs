/**
  <summary>Primitive PDF object types [PDF:1.6:3.2], along with related extensions [PDF:1.6:3.8].</summary>
*/
namespace org.pdfclown.objects{}
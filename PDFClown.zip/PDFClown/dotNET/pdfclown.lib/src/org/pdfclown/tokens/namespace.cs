/**
  <summary>PDF file serialization [PDF:1.6:3].</summary>
*/
namespace org.pdfclown.tokens{}
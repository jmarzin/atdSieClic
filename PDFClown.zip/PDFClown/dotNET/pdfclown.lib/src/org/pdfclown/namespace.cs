/**
  <summary>Root namespace of PDF Clown library.</summary>
*/
namespace org.pdfclown{}